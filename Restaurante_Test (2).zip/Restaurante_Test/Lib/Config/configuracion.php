<?php
    $host="localhost";
	$user="root";
	$pass="";
	$database="___bd_restaurante";
?>