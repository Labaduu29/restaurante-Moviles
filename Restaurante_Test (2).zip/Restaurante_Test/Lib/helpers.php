<?php
@session_start();
function getUrl($modulo,$controlador,$funcion,$parametros=false, $ajax=false)
{
    if($ajax==false)
    {
        $pagina="index";
    }
    else
    {
        $pagina="ajax";
    }
			
    $url="$pagina.php?modulo=$modulo&controlador=$controlador&funcion=$funcion";

    if($parametros!=false){
            foreach($parametros as $key=>$valor){
                    $url.="&$key=$valor";
            }
    }

    return $url;
}

function getTitle($modulo,$funcion)
{

	$return="";
	
	return $return;
}

function dd($variable){
	echo "<pre>";
	die(print_r($variable));
}

function redirect($url){
	echo "<script type='text/javascript'>
	window.location.href='$url';</script>";
}

function setErrores($errores = array()) {

    $mensajeError = "";

    if (is_array($errores) && count($errores) > 0) {

        $mensajeError = "<h6><strong>Por favor corregir los siguientes errores: </strong></h6>"
                . "<ul>";

        foreach ($errores as $error) {

            $mensajeError .= "<li>* " . $error . "</li>";
        }

        $mensajeError .= "</ul>";
    }

    $_SESSION['mensajeError'] = $mensajeError;
}

function getErrores() {

    $mensajeError = "";

    if (isset($_SESSION['mensajeError'])) {

        $mensajeError = $_SESSION['mensajeError'];
        unset($_SESSION['mensajeError']);
    }

    return $mensajeError;
}


function cargarPrincipal()
{  	
    if(!isset($_GET['modulo']) && !isset($_GET['controlador']) && !isset($_GET['funcion'])){  
		
		include_once "../View/Partials/slider_principal.php";	
		//include_once "../View/Partials/dashboard.php";
    }
    else
    {
      
        $modulo= ucwords($_GET['modulo']);
        $controlador= ucwords($_GET['controlador']);
        $funcion= $_GET['funcion'];   
        
     

       if(is_dir("../Controller/" . $modulo))
        {
           
            if(file_exists("../Controller/" . $modulo . "/".$controlador."Controller.php"))
            {  
               
               include_once('../Controller/' . $modulo . '/'. $controlador.'Controller.php');    
                                 
                $nombreClase= $controlador ."Controller";
                $objControlador= new $nombreClase();

                if(method_exists($objControlador,$funcion))
                {
                    $objControlador->$funcion();
                }
                else
                {
                    die("La funcion especificada no existe");
                }

            }
            else
            {
                die("El controlador especificado no existe");
            }
        }
        else
        {
            die("El modulo especificado no existe");
        }
    
    }
}


function NombreMes($mes)
{
       switch ($mes) {
        case 1:
            $nombre="Enero";
        break;
        case 2:
               $nombre="Febrero";
           break;
        case 3:
               $nombre="Marzo";
           break;

        case 4:
               $nombre="Abril";
           break;
        case 5:
               $nombre="Mayo";
           break;
        case 6:
                   $nombre="Junio";
               break;
           case 7:
                   $nombre="Julio";
               break;
           case 8:
                   $nombre="Agosto";
               break;
           case 9:
                   $nombre="Septiembre";
               break;

           case 10:
                   $nombre="Octubre";
               break;
           case 11:
                   $nombre="Noviembre";
               break;
           case 12:
                   $nombre="Diciembre";
               break;
    
       }
       return $nombre;
    
	
	
}

function alertas($mensaje){
	echo "<script type='text/javascript'>
		alert('$mensaje');
	</script>";
}

?>