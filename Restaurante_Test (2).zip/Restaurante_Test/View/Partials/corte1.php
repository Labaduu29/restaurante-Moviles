<section class="hero-section">
	<div class="container">

	<div  class="titulo">
			<h2>Curso - Power BI</h2>
		</div>

		<div >
			<h4>Datos para la inscripci&oacute;n</h4>
		</div>
		<div class="row">											
			<form method="post" action="#">
                <div class="form-group">
                  	<div class="col-md-1 col-lg-6 col-xs-1 ocultarMovil">
                            <img src="../Web/img/img1.png">
                    </div>
             
					<div class="col-md-1 col-lg-3 col-xs-12">
						<label > Nombre Completo</label>
					</div>	
					<div class="col-md-1 col-lg-3 col-xs-12">
						<input type="text" class="form-control" value="">
					</div>	
						
					<div class="col-md-1 col-lg-3 col-xs-12">
							<label> Correo </label>
					</div>
					<div class="col-md-2 col-lg-3 col-xs-12">
						<input type="email" class="form-control" name="correo" >
					</div>
				</div>	
				<div class="col-md-1 col-lg-3 col-xs-12">
					<label> Facultad </label>
				</div>
				<div class="col-md-2 col-lg-3 col-xs-12">
					<select type="text" class="form-control" name="facultad" >
                        <option value="1">Ingenieria</option>
                        <option value="1">Medicina</option>
                    </select>
				</div>
				<div class="col-md-1 col-lg-3 col-xs-12">
					<label> Rol </label>
				</div>
				<div class="col-md-2 col-lg-3 col-xs-12">
					<select type="text" class="form-control" name="rol" >
                        <option value="1">Estudiante</option>
                        <option value="1">Profesor</option>
                    </select>
				</div>

                <div class="col-md-1 col-lg-3 col-xs-12 ocultarMovil"> 
					<label> Foto Documento de identidad </label>
				</div>
				<div class="col-md-2 col-lg-3 col-xs-12 ocultarMovil">
					<input type="file" class="form-control" name="foto" >                    
				</div>
			
				<br><br>
				<div class="form-group">
					<div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
						<button class="btn btn-primary" type="submit">Registrar</button>
					</div>
				</div>
			</form><br><br><br>											
			</div>
		</div>
</section>