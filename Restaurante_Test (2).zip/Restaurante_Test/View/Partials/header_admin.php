<header class="header-section">
		<div class="header-top">
			<div class="container">
				

				
				<div class="user-panel">					
					<a href="index.php?modulo=Sesion&controlador=Sesion&funcion=CerrarSesion" >Cerrar Sesión</a>
				</div>
			</div>
		</div>		




		<div class="header-bottom">
			<div class="container">
				<a href="index.php" class="site-logo">
					<img src="img/logo.png" alt="">
				</a>	

							
				
				<ul class="main-menu dropdown-submenu">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						Archivo<b class="caret"></b>
						</a>
						<ul class="dropdown-menu">							
							<li class="dropdown-submenu">
												<a tabindex="-1" href="index.php?modulo=Estado&controlador=Estado&funcion=index">Estado &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>								
							</li>							 							 
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						Documentos <b class="caret"></b>
						</a>
						<ul class="dropdown-menu">
							<li class="dropdown-submenu">
								<a tabindex="-1" href="index.php?modulo=Comanda&controlador=Comanda&funcion=index">Comanda &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							<li><a tabindex="-1" href="index.php?modulo=Egreso&controlador=Egreso&funcion=getCrearEgreso">Comprobante Egreso &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							<li><a tabindex="-1" href="index.php?modulo=Pedido&controlador=Pedido&funcion=getInsertar">Pedido &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							<li><a tabindex="-1" href="index.php?modulo=Recibo&controlador=Recibo&funcion=index">Recibo de Caja &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						Reporte <b class="caret"></b>
						</a>
						<ul class="dropdown-menu">
						<li class="dropdown-submenu">
<a tabindex="-1" href="index.php?modulo=Pedido&controlador=Pedido&funcion=getCorteI">Corte 1 &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>							</li>
						</ul>
					</li>
				</ul>							



			</div>
			
		</div>
	</header>