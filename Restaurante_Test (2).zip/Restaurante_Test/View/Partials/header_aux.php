<header class="header-section">
		<div class="header-top">
			<div class="container">
				<div class="header-social">
					<a href="#"><i class="fa fa-pinterest"></i></a>
					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-dribbble"></i></a>
					<a href="#"><i class="fa fa-behance"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
				</div>

				
				<div class="user-panel">					
					<a href="index.php?modulo=Sesion&controlador=Sesion&funcion=CerrarSesion" >Cerrar Sesión</a>
				</div>
			</div>
		</div>
		<div class="header-bottom">
			<div class="container">
				<a href="index.php" class="site-logo">
					<img src="img/logo.png" alt="">
				</a>	

				<!--- Menú  Admin-->
				<ul class="main-menu dropdown-submenu">
					
					
					<li class="dropdown-submenu">
						<a class="test" href="#">Documentos <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li class="dropdown-submenu">
								<a tabindex="-1" href="index.php?modulo=Comanda&controlador=Comanda&funcion=index">Comanda &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>								
							</li>
							<li><a tabindex="-1" href="index.php?modulo=Pedido&controlador=Pedido&funcion=getInsertar">Pedido &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							
						</ul>
					</li>
						

				</ul>
					
				<!-- Menu Generico  -->																										
			</div>
			
		</div>
	</header>