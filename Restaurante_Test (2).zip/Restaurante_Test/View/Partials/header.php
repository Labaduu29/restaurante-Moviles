<header class="header-section">
		<div class="header-top">
			<div class="container">
				<div class="header-social">
					<a href="#"><i class="fa fa-pinterest"></i></a>
					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-dribbble"></i></a>
					<a href="#"><i class="fa fa-behance"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
				</div>
				<div class="user-panel">					
					<a href="#" data-toggle="modal" data-target="#Iniciar_Sesion">Iniciar Sesión</a>
				</div>
			</div>
		</div>
		<div class="header-bottom">
			<div class="container">
				<a href="page.php" class="site-logo">
					<img src="img/logo.png" alt="">
				</a>	

				
					
				<!-- Menu Generico  -->																										
			</div>
			
		</div>
	</header>