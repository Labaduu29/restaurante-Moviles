<section class="hero-section">
		
		<div class="container" >
			<div class="section-title">
				<h2>Lista de Pedidos</h2>
			</div>
			<div class="row">
	
				<table class="table table" id="table_pedido">
					<thead>
						
						<tr >							
							<th >No pedido</th>
							<th >Fecha</th>					
							<th >Mesa</th>					
							<th >Estado</th>
							<th colspan="2" >Acción</th>
						</tr>
					</thead>
					<tbody id="tbody_pedido">
						<?php
						if($pedidos->num_rows > 0){

							
							foreach($pedidos as $pedido){
								echo'<tr>
								<td>'.$pedido['ped_id'].'</td>
								<td>'.$pedido['ped_fecha'].'</td>
								<td>'.$pedido['ped_mesa'].'</td>
								<td>'.$pedido['est_descripcion'].'</td>								
								<td><a href="index.php?modulo=Pedido&controlador=Pedido&funcion=ver&num_doc='.$pedido['ped_id'].'">
									<button type="button" class="btn btn-success " id="btn">Ver más</button>
								</a></td>
								<td><a href="index.php?modulo=Recibo&controlador=Recibo&funcion=getPagar&num_doc='.$pedido['ped_id'].'">
								<button type="button" class="btn btn-primary">Pagar</button>
							</a></td>
							</tr>';
							}
						}
						else{
							echo"<tr><td></td><td>No hay Registros</td></tr>";
						}
						?>
					</tbody>
				</table>															
			</div>
		</div>
	
</section>