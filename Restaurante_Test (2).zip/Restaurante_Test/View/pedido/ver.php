<section class="hero-section">
		
		<div class="container" >
			<div class="section-title">
				<h2>Ver Pedido</h2><small><a href="index.php?modulo=Pedido&controlador=Pedido&funcion=index">Ver lista de Pedidos</a></small>
			</div>
			<div class="row">
				<?php foreach($cabecera as $cab){} ?>													
				<form name="frm_pedido" method="post" action="#">
					<div class="form-group">
						<div class="col-md-1 col-lg-1 col-xs-1">
							<label>No:</label>
						</div>
						<div class="col-md-2 col-lg-2 col-xs-2">
							<input type="num_doc" readonly class="form-control" name="num_doc" value="<?php echo $num_doc; ?>">
						</div>
						<div class="col-md-1 col-lg-1 col-xs-1">
							<label for="pwd">Fecha: </label>
						</div>
						<div class="col-md-2 col-lg-2 col-xs-2">
							<input type="text" readonly class="form-control" name="fecha" value="<?php echo $cab['ped_fecha']; ?>">
						</div>
						<div class="col-md-1 col-lg-1 col-xs-1">
							<label for="email">Mesa:</label>
						</div>
						<div class="col-md-2 col-lg-2 col-xs-2">
							<input type="text" class="form-control" readonly id="mesa" name="mesa" value="<?php echo $cab['ped_mesa']; ?>">
						</div>
						<div class="col-md-1 col-lg-1 col-xs-1">
							<label for="email">Estado:</label>
						</div>
						<div class="col-md-2 col-lg-2 col-xs-2">
							<input type="text" class="form-control" readonly id="mesa" name="mesa" value="<?php echo $cab['est_descripcion']; ?>">
						</div>
					</div>
					<br>
					<br>
					<br>
					
					<table class="table table-bordered" id="table_pedido">
						<thead>
							<tr><th colspan="5" style="text-align:center; background-color:#F0EAE9; ">Detalle del Pedido</th></tr>
							<tr ><th>Plato</th>
							<th width="10%">Precio</th>
							<th width="10%">Cantidad</th>
							<th width="35%">Observaciones</th>							
						</thead>
						<tbody id="tbody_pedido">
							<?php
							foreach($detalle as $deta){
								echo'<tr>
									<td><input type="text" name="plato[]" readonly class="form-control" value="'.$deta['pla_descripcion'].'"></td>
									<td style="text-align:right"><input type="text" name="precio[]" readonly class="form-control" value="'.number_format($deta['ped_det_precio']).'"></td>
									<td style="text-align:right"><input type="text" name="cantidad[]" readonly class="form-control" value="'.number_format($deta['ped_det_cant']).'"></td>
									<td><input type="text" name="observa[]" readonly class="form-control" value="'.$deta['ped_det_obser'].'"></td>
									
								</tr>';
							}
							?>
						</tbody>
					</table>
					
					<div class="form-group">
						<div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
							<a href="<?php echo getUrl("Pedido", "Pedido", "index"); ?>"><input type="button" class="btn btn-primary" value="Regresar"></a>
						</div>
					</div>
				</form>
													
			</div>
		</div>
	
</section>