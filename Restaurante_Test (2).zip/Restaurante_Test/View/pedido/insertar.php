<section class="hero-section">
		
		<div class="container" >
			<div class="section-title">
				<h2>Crear Nuevo Pedido</h2><small><a href="index.php?modulo=Pedido&controlador=Pedido&funcion=index">Ver lista de Pedidos</a></small>
			</div>
			<div class="row">
																	
				<form name="frm_pedido" method="post" action="<?php //echo getUrl("Pedido", "Pedido", "postInsertar"); ?>">
					<div class="form-group">
						<div class="col-md-1 col-lg-1 col-xs-1">
							<label>No:</label>
						</div>
						<div class="col-md-2 col-lg-2 col-xs-2">
							<input type="num_doc" readonly class="form-control" name="num_doc" value="<?php //echo $num_doc; ?>">
						</div>
						<div class="col-md-1 col-lg-1 col-xs-1">
							<label for="pwd">Fecha: </label>
						</div>
						<div class="col-md-4 col-lg-4 col-xs-4">
							<input type="date" required class="form-control" name="fecha">
						</div>
						<div class="col-md-1 col-lg-1 col-xs-1">
							<label for="email">Mesa:</label>
						</div>
						<div class="col-md-2 col-lg-2 col-xs-2">
							<input type="text" class="form-control" required id="mesa" name="mesa">
						</div>
					</div>
					<br>
					<br>
					<br>
					
					<table class="table table-bordered" id="table_pedido">
						<thead>
							<tr><th colspan="5" style="text-align:center; background-color:#F0EAE9; ">Detalle del Pedido</th></tr>
							<tr ><th>Plato</th>
							<th width="10%">Precio</th>
							<th width="10%">Cantidad</th>
							<th width="35%">Observaciones</th>
							<th width="5%"><button type="button" class="btn btn-primary" id="btn_pedido">+</button></th></tr>
						</thead>
						<tbody id="tbody_pedido">
							<tr id="tr_pedido" style="display:none">
								<td>
									<select name="plato[]" class="form-control ">
										<option>Seleccione</option>
										<?php
											/*foreach($platos as $plato)
											{
												echo"<option value='".$plato['pla_id']."'>".$plato['pla_descripcion']."</option>";
											}*/
										?>
									</select>
								</td>
								<td><input type="number" name="precio[]" class="form-control"></td>
								<td><input type="number" name="cantidad[]" class="form-control"></td>
								<td><input type="text" name="observa[]" class="form-control"></td>
								<td><button type="button" class="btn btn-danger eliminar" id="btn">-</button></td>
							</tr>

							<tr>
								<td>
									<select name="plato[]" class="form-control ">
										<option>Seleccione</option>
										<?php
											/*foreach($platos as $plato)
											{
												echo"<option value='".$plato['pla_id']."'>".$plato['pla_descripcion']."</option>";
											}*/
										?>
									</select>
								</td>
								<td><input type="number" name="precio[]" required class="form-control"></td>
								<td><input type="number" name="cantidad[]" required class="form-control"></td>
								<td><input type="text" name="observa[]" required class="form-control"></td>
								<td><button type="button" class="btn btn-danger eliminar" id="btn">-</button></td>
							</tr>
						</tbody>
					</table>
					
					<div class="form-group">
						<div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
							<input type="submit" class="btn btn-primary" value="Registrar">
						</div>
					</div>
				</form>
													
			</div>
		</div>
	
</section>