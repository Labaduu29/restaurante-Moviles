<?php
    $tipoEst = mysqli_fetch_object($tes);
    $estado = mysqli_fetch_object($est);
?>
<section class="hero-section">
         <div class="container">
            <div class="section-title">
                <h2>Modificar Estado</h2>
            </div>
                <div class="row">                                                 
                    <form method="post" action="<?php echo getUrl("Estado","Estado","postModificar"); ?>">
                    <div class="form-group">
                        <div class="col-md-1 col-lg-1 col-xs-1">
                            <label > N°</label>
                        </div>	
                            <div class="col-md-2 col-lg-2 col-xs-2">
                                <input readonly type="number" class="form-control" name="est_id" value= "<?php echo $estado->est_id; ?>">
                            </div>	
                                <div class="col-md-1 col-lg-1 col-xs-1">
                                    <label>Descripci&oacute;n</label>
                                </div>
                                    <div class="col-md-2 col-lg-2 col-xs-2">
                                        <input type="text" class="form-control" name="est_descripcion" value= "<?php echo UTF8_encode($estado->est_descripcion); ?>" >
                                    </div>
                                        <div class="col-md-1 col-lg-1 col-xs-1">
                                            <label >Tipo Estado </label>
                                        </div>
                                            <div class="col-md-2 col-lg-2 col-xs-2">
                                                <select class="select2_single form-control" name="tes_id">
                                                    <option value="0">Selecionar...</option>
                                                        <?php
                                                            foreach($tes as $tipoEst){
                                                                $select="";
                                                                if($tipoEst['tes_id']==$estado->tes_id){
                                                                    $select="selected";
                                                                }
                                                                echo "<option value='".$tipoEst['tes_id']."' $select>".UTF8_encode($tipoEst['tes_descripcion'])."</option>";
                                                                $select="";
                                                            }
                                                        ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-xs-1">
                                            <label > Estado </label>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-xs-2">
                                                <select class="select2_single form-control" name="est_estado">
                                                    <option value="seleccionar">Selecionar...</option>
                                                    <option value="Activo">Activo</option>
                                                    <option value="Inactivo">Inactivo</option>
                                                        
                                                </select>
                                            </div>
                                        </div>
                     <div class="form-group">
                           <div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                                <a class='btn btn-default' href="<?php echo getUrl("Estado","Estado","index"); ?>">Cancelar</a> 
                            </div>
                        </div>
                    </form><br><br><br>                           
         </div>
    </div>
</section>