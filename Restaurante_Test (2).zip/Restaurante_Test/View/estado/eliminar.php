
<?php
    
    $estado = mysqli_fetch_object($est);
?>
<section class="hero-section">
         <div class="container">
            <div class="section-title">
                <h2>Elimiar Estado</h2>
            </div>
                <div class="row">                                                 
                    <form method="post" action="<?php echo getUrl("Estado","Estado","postEliminar"); ?>">
                    <div class="form-group ">
                        <div class="col-md-1 col-lg-1 col-xs-1">
                            <label > N°</label>
                        </div>	
                        <div class="col-md-2 col-lg-2 col-xs-2">
                            <input readonly type="number" class="form-control" name="est_id" value= "<?php echo $estado->est_id; ?>">
                        </div>	
                        <div class="col-md-1 col-lg-1 col-xs-1">
                            <label>Descripci&oacute;n</label>
                        </div>
                        <div class="col-md-2 col-lg-2 col-xs-2">
                            <input type="text" class="form-control" readonly name="est_descripcion" value= "<?php echo UTF8_encode($estado->est_descripcion); ?>" >
                        </div>
                    </div>                    
                    <br><br>         
                    <div class="form-group">
                           <div class="col-md-7 col-lg-7 col-xs-7" style="text-align:center">
                                <button class="btn btn-primary" type="submit">Eliminar</button>
                                <a class='btn btn-default' href="<?php echo getUrl("Estado","Estado","index"); ?>">Cancelar</a> 
                            </div>
                    </div>
                    </form><br><br><br>                           
         </div>
    </div>
</section>