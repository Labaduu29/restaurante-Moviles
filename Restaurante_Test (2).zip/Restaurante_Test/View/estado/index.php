<section class="hero-section">
    <div class="hero-slider owl-carousel">		
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-9 col-xs-12 section-title">
                    <h2>Estado</h2>						
                </div>
                <br>
                <div class="col-lg-9 col-md-3 col-xs-12"><a href="<?php echo getUrl("Estado", "Estado", "getInsertar"); ?>">
                        <button type="submit" class="btn btn-success">Crear un Nuevo Estado </button></a>
                </div>
            </div>

            <div class="row ocultarMovil" >
                <div class="table-responsive">
                    <table class="table table-bordered text-center tables">
                        <thead>
                            <tr >
                                <th class="text-center">ID</th>
                                <th class="text-center">Descripci&oacute;n</th>
                                <th class="text-center">Tipo Estado</th>
                                <th class="text-center">Estado</th>
                                <th class="text-center">Editar</th>
                                <th class="text-center">Eliminar</th>     

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($est) {
                                foreach ($est as $estado) {
                                    echo"<tr>";
                                    echo"<td>" . ($estado['est_id']) . "</td>";
                                    echo"<td>" . UTF8_encode($estado['est_descripcion']) . "</td>";
                                    echo"<td>" . UTF8_encode($estado['tes_descripcion']) . "</td>";
                                    echo"<td>" . ($estado['est_estado']) . "</td>";
                                    echo"<td>";
                                    echo"<div class='icon-reorder tooltips' data-original-title='Modificar' data-placement='bottom'>
                                                                  <a class='btn btn-warning' href='" . getUrl("Estado", "Estado", "getModificar", array("id" => $estado['est_id'])) . "'><i class='fa fa-edit'></i></a>
                                                                </div></td>";
                                    echo"<td>";
                                    echo"<div class='icon-reorder tooltips' data-original-title='Eliminar' data-placement='bottom'>
                                                                  <a class='btn btn-danger' href='" . getUrl("Estado", "Estado", "getEliminar", array("id" => $estado['est_id'])) . "'><i class='fa fa-trash-o'></i></a>
                                                                </div></td>";
                                    echo "</tr>";
                                }
                            }
                            ?>
                             <tr >
                                <th class="text-center">1</th>
                                <th class="text-center">Disponible</th>
                                <th class="text-center">Plato</th>
                                <th class="text-center">Activo</th>
                                <th class="text-center">Editar</th>
                                <th class="text-center">Eliminar</th>     

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
</section>
</form> 