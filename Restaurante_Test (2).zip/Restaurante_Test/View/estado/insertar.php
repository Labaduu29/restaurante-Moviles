<section class="hero-section">
		
				<div class="container">
					<div class="section-title">
						<h2>Crear Estado</h2>
					</div>
					
																			
						<form method="post" action="<?php echo getUrl("Estado","Estado","postInsertar"); ?>">
						
                                                    <div class="row">
                                                        
                                                        <div class="form-group">
                                                            <div class="col-md-1 col-lg-1 col-xs-4">
                                                                    <label > N°</label>
                                                            </div>	
                                                            <div class="col-md-2 col-lg-2 col-xs-8">
                                                                    <input readonly type="text" class="form-control" value="">
                                                            </div>	
                                                            <div class="col-md-1 col-lg-1 col-xs-12">
                                                                        <label>Descripci&oacute;n</label>
                                                            </div>
                                                            <div class="col-md-3 col-lg-3 col-xs-12">
                                                                <input type="text" class="form-control" name="est_descripcion" >
                                                            </div>
                                                            <div class="col-md-1 col-lg-1 col-xs-1">
                                                                <label >Tipo Estado </label>
                                                            </div>
                                                            <div class="col-md-3 col-lg-3 col-xs-3">
                                                                <select class="select2_single form-control" name="tes_id">
                                                                        <option value="0">Selecionar...</option>
                                                                                <?php
                                                                               /* foreach($tes as $tipEsta){
                                                                                echo "<option value='".$tipEsta['tes_id']."'>".utf8_encode($tipEsta['tes_descripcion'])."</option>";
                                                                                }*/
                                                                                ?>
                                                                </select>
                                                            </div>
                                                        </div>							  															
                                                    </div>
                                                    <div class="form-group">
                                                                <div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
									<button class="btn btn-primary" type="submit">Guardar</button>
									<a class='btn btn-default' href="<?php echo getUrl("Estado","Estado","index"); ?>">Cancelar</a> 
								</div>
                                                    </div>
						</form><br><br><br>
			
		</div>
	</section>