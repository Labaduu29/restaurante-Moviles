<section class="hero-section">
	<div class="hero-slider owl-carousel">
	
		<div class="container">
		
			<div class="row">
				<div class="col-md-9 col-xs-3 section-title">
					<h2>Cliente</h2>						
				</div>
				<br>
				<div class="col-md-3 col-xs-3"><a href="<?php //echo getUrl("Cliente","Cliente","getInsertar");?>">
						<button type="submit" class="btn btn-success">Crear un Nuevo Cliente </button></a>
				</div>
			</div>
				
	  
			<table class="table table-bordered text-center tables ">
				<thead>
					<tr>
					  <th class="text-center">ID</th>
					  <th class="text-center">Nombre</th>
					  <th class="text-center">Apellidos</th>
					  <th class="text-center">Direcci&oacute;n</th>
					  <th class="text-center">Tel&eacute;fono</th>
					  <th class="text-center">Editar</th>
					  <th class="text-center">Eliminar</th>     

					</tr>
				</thead>
				  <tbody>
				  <?php
								foreach($cli as $cliente){
									echo"<tr >";
									echo"<td>". ($cliente['cli_id']) . "</td>";
									echo"<td>". UTF8_encode($cliente['cli_nombre']) . "</td>";
									echo"<td>". UTF8_encode($cliente['cli_apellidos']) . "</td>";
									echo"<td>". UTF8_encode($cliente['cli_direccion']) . "</td>";
									echo"<td>". ($cliente['cli_telefono']) . "</td>";
									echo"<td>";

									echo"<div class='icon-reorder tooltips' data-original-title='Modificar' data-placement='bottom'>
							       <a class='btn btn-warning' href='". getUrl("Cliente","Cliente","getModificar",array("id"=>$cliente['cli_id']))."'><i class='fa fa-edit'></i></a>
							      </div></td>";
									echo"<td>";
									echo"<div class='icon-reorder tooltips' data-original-title='Eliminar' data-placement='bottom'>
									  <a class='btn btn-danger' href='". getUrl("Cliente","Cliente","getEliminar",array("id"=>$cliente['cli_id']))."'><i class='fa fa-trash-o'></i></a>
									</div></td>";
									echo "</tr>";
								}
							?>
				  </tbody>
			</table>

			</div>
		
	</div>
</section>
