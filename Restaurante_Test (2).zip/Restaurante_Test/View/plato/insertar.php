<section class="hero-section">
	<div class="container">
		<div class="section-title">
			<h2>Crear plato</h2>
		</div>
		<div class="row">											
			<form method="post" action="<?php echo getUrl("Plato","Plato","postInsertar"); ?>">
				<div class="form-group">
					<div class="col-md-1 col-lg-1 col-xs-1">
						<label > N°</label>
					</div>	
					<div class="col-md-1 col-lg-1 col-xs-1">
						<input readonly type="text" class="form-control" value="<?php echo $pla_id; ?>">
					</div>	
						
					<div class="col-md-1 col-lg-1 col-xs-1">
							<label> Descripci&oacute;n </label>
					</div>
					<div class="col-md-2 col-lg-2 col-xs-2">
						<input type="text" class="form-control" name="pla_descripcion" >
					</div>
				</div>	
				<div class="col-md-1 col-lg-1 col-xs-1">
					<label> Precio </label>
				</div>
				<div class="col-md-2 col-lg-2 col-xs-2">
					<input type="text" class="form-control" name="pla_precio" >
				</div>
				<div class="col-md-1 col-lg-1 col-xs-1">
					<label > Estado </label>
				</div>
				<div class="col-md-2 col-lg-2 col-xs-2">
					<select class="select2_single form-control" name="est_id">
						<option value="0">Selecionar...</option>
							<?php
								foreach($es as $estado){
								echo "<option value='".$estado['est_id']."'>".utf8_encode($estado['est_descripcion'])."</option>";
								}
							?>
					</select>
				</div>
			
				<br><br>
				<div class="form-group">
					<div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
						<button class="btn btn-primary" type="submit">Guardar</button>
						<a class='btn btn-default' href="<?php echo getUrl("Plato","Plato","index"); ?>">Cancelar</a> 
					</div>
				</div>
			</form><br><br><br>											
			</div>
		</div>
</section>