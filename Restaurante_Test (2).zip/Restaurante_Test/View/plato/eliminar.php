<?php $plato = mysqli_fetch_object($pla);?>
<section class="hero-section">
<div class="container">
	<div class="section-title">
		<h2>Eliminar Plato</h2>
	</div>
	<div class="row">											
		<form method="post" action="<?php echo getUrl("Plato","Plato","postEliminar"); ?>">
		<div class="form-group">
			<div class="col-md-1 col-lg-1 col-xs-1">
				<label > N°</label>
			</div>	
			<div class="col-md-1 col-lg-1 col-xs-1">
				<input readonly type="text" name="pla_id" class="form-control" value="<?php echo $plato->pla_id; ?>">
			</div>	
				
			<div class="col-md-1 col-lg-1 col-xs-1">
					<label> Descripci&oacute;n </label>
				</div>
				<div class="col-md-2 col-lg-2 col-xs-2">
					<input readonly type="text" class="form-control" name="pla_descripcion"  value= "<?php echo UTF8_encode($plato->pla_descripcion); ?>">
				</div>
			</div>		
			</div>
		</div>
			<br>
			<div class="form">
            <div class="col-md-7 col-lg-7 col-xs-7" style="text-align:center">
                <button class="btn btn-primary" type="submit">Eliminar</button>
					<a class='btn btn-default' href="<?php echo getUrl("Plato","Plato","index"); ?>">Cancelar</a> 
				</div>
			</div>
		</form><br><br><br>											
		</div>
	</div>
</section>