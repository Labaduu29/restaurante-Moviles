<section class="hero-section">		
    <div class="container">
		<div class="section-title">
				<h2>Crear Perfil</h2>
		</div>


		<form method="post" action="<?php echo getUrl("Perfil","Perfil","postInsertar"); ?>">
			<div class="row">
				<div class="form-group">
					<div class="col-md-1 col-lg-1 col-xs-1">
							<label > N°</label>
					</div>	
					<div class="col-md-2 col-lg-2 col-xs-2">
							<input readonly type="text" class="form-control" value="<?php echo $perf_id; ?>">
					</div>	
					<div class="col-md-1 col-lg-1 col-xs-1">
							<label>Descripci&oacute;n</label>
					</div>
					<div class="col-md-3 col-lg-3 col-xs-3">
						<input type="text" class="form-control" name="perf_descripcion" >
					</div>
					<div class="col-md-1 col-lg-1 col-xs-1">
						<label > Estado </label>
					</div>
					<div class="col-md-3 col-lg-3 col-xs-3">
						<select class="select2_single form-control" name="perf_estado">
								<option value="seleccionar">Selecionar...</option>
								<option value="activo">Activo</option>
								<option value="inactivo">Inactivo</option>

						</select>
					</div>
				</div>
			</div>
			<br>
			<div class="form-group">
					<div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
							<button class="btn btn-primary" type="submit">Guardar</button>
							<a class='btn btn-default' href="<?php echo getUrl("Perfil","Perfil","index"); ?>">Cancelar</a> 
					</div>
			</div>
		</form><br><br><br>
	</div>
</section>