<?php  $perfil = mysqli_fetch_object($perf);?>
<section class="hero-section">
         <div class="container">
            <div class="section-title">
                <h2>Eliminar Perfil</h2>
            </div>
                <div class="row">                                                 
                    <form method="post" action="<?php echo getUrl("Perfil","Perfil","postEliminar"); ?>">
                    <div class="form-group">
                        <div class="col-md-1 col-lg-1 col-xs-1">
                            <label > N°</label>
                        </div>	
                            <div class="col-md-2 col-lg-2 col-xs-2">
                                <input readonly type="number" class="form-control" name="perf_id" value= "<?php echo $perfil->perf_id; ?>">
                            </div>	
                                <div class="col-md-1 col-lg-1 col-xs-1">
                                    <label>Descripci&oacute;n</label>
                                </div>
                                    <div class="col-md-2 col-lg-2 col-xs-2">
                                        <input readonly type="text" class="form-control" name="perf_descripcion" value= "<?php echo UTF8_encode($perfil->perf_descripcion); ?>" >
                                    </div>
                                        </div>
                                         <br><br><br><br>
                        <div class="form">
                        <div class="col-md-7 col-lg-7 col-xs-7" style="text-align:center">
                                <button class="btn btn-primary" type="submit">Eliminar</button>
                                <a class='btn btn-default' href="<?php echo getUrl("Perfil","Perfil","index"); ?>">Cancelar</a> 
                            </div>
                        </div>
                    </form><br><br><br>                           
         </div>
    </div>
</section>