<section class="hero-section">
	<div class="hero-slider owl-carousel">		
		<div class="container">
			<div class="row">
				<div class="col-md-9 col-xs-3 section-title">
					<h2>Perfil</h2>						
				</div>
				<br>
				<div class="col-md-3 col-xs-3"><a href="<?php echo getUrl("Perfil","Perfil","getInsertar");?>">
						<button type="submit" class="btn btn-success">Crear un Nuevo Perfil </button></a>
				</div>
			</div>
          
          
			<table class="table table-bordered text-center tables">
			  <thead>
				<tr>
				  <th class="text-center">ID</th>
				  <th class="text-center">Descripci&oacute;n</th>
				  <th class="text-center">Estado</th>
				  <th class="text-center">Editar</th>
				  <th class="text-center">Eliminar</th>     

				</tr>
				</thead>
				<tbody>
					<?php
					foreach($perf as $perfil){
						echo"<tr>";
						echo"<td>". $perfil['perf_id'] . "</td>";
						echo"<td>". UTF8_encode($perfil['perf_descripcion']) . "</td>";
						echo"<td>". $perfil['perf_estado'] . "</td>";
						echo"<td>";
						echo"<div class='icon-reorder tooltips' data-original-title='Modificar' data-placement='bottom'>
						  <a class='btn btn-warning' href='". getUrl("Perfil","Perfil","getModificar",array("id"=>$perfil['perf_id']))."'><i class='fa fa-edit'></i></a>
						</div></td>";
						echo"<td>";
						echo"<div class='icon-reorder tooltips' data-original-title='Eliminar' data-placement='bottom'>
						  <a class='btn btn-danger' href='". getUrl("Perfil","Perfil","getEliminar",array("id"=>$perfil['perf_id']))."'><i class='fa fa-trash-o'></i></a>
						</div></td>";
						echo "</tr>";
					}
				?>
				</tbody>
			</table>
		</div>
	</div>
</section>
 