
<?php $tpqrs = mysqli_fetch_object($tp);?>
<section class="hero-section">
<div class="container">
	<div class="section-title">
		<h2>Eliminar Cliente</h2>
	</div>
	<div class="row">											
		<form method="post" action="<?php echo getUrl("TipoTpqrs","TipoTpqrs","postEliminar"); ?>">
		<div class="form-group">
			<div class="col-md-1 col-lg-1 col-xs-1">
            <label > N°</label>
                    </div>	
                    <div class="col-md-2 col-lg-2 col-xs-2">
                        <input readonly type="text" class="form-control" name="tpqrs_id" value=" <?php echo $tpqrs->tpqrs_id; ?>">
                    </div>	
                    <div class="col-md-1 col-lg-1 col-xs-1">
                        <label>Nombre(s)</label>
                    </div>
                    <div class="col-md-3 col-lg-3 col-xs-3">
                        <input readonly type="text" class="form-control" name="tpqrs_descripcion" value= "<?php echo $tpqrs->tpqrs_descripcion; ?>">
                    </div>  
			</div>
		</div>
			<br>
			<div class="form">
            <div class="col-md-7 col-lg-7 col-xs-7" style="text-align:center">
					<button class="btn btn-primary" type="submit">Eliminar</button>
					<a class='btn btn-default' href="<?php echo getUrl("TipoTpqrs","TipoTpqrs","index"); ?>">Cancelar</a> 
				</div>
			</div>
		</form><br><br><br>											
		</div>
	</div>
</section>

