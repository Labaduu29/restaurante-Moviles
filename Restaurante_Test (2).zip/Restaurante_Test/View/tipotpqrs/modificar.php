<?php $tpqrs = mysqli_fetch_object($tp);?>
<section class="hero-section">
<div class="container">
	<div class="section-title">
		<h2>Modificar Tipo Pqrs</h2>
	</div>
	<div class="row">											
		<form method="post" action="<?php echo getUrl("TipoTpqrs","TipoTpqrs","postModificar"); ?>">
		<div class="form-group">
			<div class="col-md-1 col-lg-1 col-xs-1">
				<label > N°</label>
			</div>	
			<div class="col-md-1 col-lg-1 col-xs-1">
				<input readonly type="text" name="tpqrs_id" class="form-control" value="<?php echo $tpqrs->tpqrs_id; ?>">
			</div>	
				
			<div class="col-md-1 col-lg-1 col-xs-1">
					<label> Descripci&oacute;n </label>
				</div>
				<div class="col-md-2 col-lg-2 col-xs-2">
					<input type="text" class="form-control" name="tpqrs_descripcion"  value= "<?php echo UTF8_encode($tpqrs->tpqrs_descripcion); ?>">
				</div>
			</div>	
			<div class="col-md-1 col-lg-1 col-xs-1">
				<label> Estado </label>
			</div>
				<div class="col-md-2 col-lg-2 col-xs-2">
					<input type="text" class="form-control" readonly  name="tpqrs_estado" value= "<?php echo UTF8_encode($tpqrs->tpqrs_estado); ?>" >
				</div>
			</div>
		</div>
		<br>
			   <div class="form-group">
                            <div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
                                    <button class="btn btn-primary" type="submit">Guardar</button>
                                    <a class='btn btn-default' href="<?php echo getUrl("TipoTpqrs","TipoTpqrs","index"); ?>">Cancelar</a> 
                            </div>
                    </div>
                    </form><br><br><br>										
		</div>
	</div>
</section>