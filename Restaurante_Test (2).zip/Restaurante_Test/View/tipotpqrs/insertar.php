<section class="hero-section">
<div class="container">
	<div class="section-title">
		<h2>Crear Tipo PQRS</h2>
	</div>
											
		<form method="post" action="<?php echo getUrl("TipoTpqrs","TipoTpqrs","postInsertar"); ?>">
			<div class="row">	
				<div class="form-group">
					<div class="col-md-1 col-lg-1 col-xs-1">
						<label > N°</label>
					</div>	
					<div class="col-md-1 col-lg-1 col-xs-1">
						<input readonly type="text" class="form-control" value="<?php echo $tpqrs_id; ?>">
					</div>	
						
					<div class="col-md-1 col-lg-1 col-xs-1">
							<label> Descripci&oacute;n </label>
						</div>
						<div class="col-md-2 col-lg-2 col-xs-2">
							<input type="text" class="form-control" name="tes_descripcion" >
						</div>
					</div>	
					<div class="col-md-1 col-lg-1 col-xs-1">
						<label> Estado </label>
					</div>
					<div class="col-md-2 col-lg-2 col-xs-2">
						<input type="text" class="form-control" name="tes_estado" >
					</div>
			</div>
		
			<br>
			
                    <div class="form-group">
                            <div class="col-md-12 col-lg-12 col-xs-12" style="text-align:center">
                                    <button class="btn btn-primary" type="submit">Guardar</button>
                                    <a class='btn btn-default' href="<?php echo getUrl("TipoTpqrs","TipoTpqrs","index"); ?>">Cancelar</a> 
                            </div>
                    </div>
                    </form><br><br><br>										
		</div>
	</div>
</section>