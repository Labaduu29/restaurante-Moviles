<section class="hero-section">
	<div class="hero-slider owl-carousel">		
		<div class="container">
			<div class="row">
				<div class="col-md-9 col-xs-3 section-title">
					<h2>Reporte de Venta</h2>
				</div>
			</div>
																	
				<form name="frm_reporteVenta" id="frm_reporteVenta" method="post" action="<?php echo getUrl("Recibo", "Recibo", "crearReporte"); ?>">
               
             
                <div class="form-group">
                    <div class="col-md-3 col-lg-3 col-xs-3">
                        <select class="select2_single form-control" name="cliente" id="cliente">
							<option value="">Cliente...</option>
							<?php
							foreach($clientes as $cli){
							echo "<option value='".$cli['cli_id']."'>".utf8_encode($cli['nombres'])."</option>";
							}
							?>
						</select>
                    </div>
                    <div class="col-md-2 col-lg-2 col-xs-2">
                        <select class="select2_single form-control" name="mesero" id="mesero">
							<option value="">Mesero...</option>
							<?php
							foreach($mesero as $mes){
							echo "<option value='".$mes['usu_id']."'>".utf8_encode($mes['nombres'])."</option>";
							}
							?>
						</select>
                    </div>
                    <div class="col-md-1 col-lg-1 col-xs-1">
							<label for="pwd">Fecha Inicio: </label>
					</div>
					<div class="col-md-2 col-lg-2 col-xs-2">
						<input type="date"  class="form-control" name="fechaini" id="fechaini">
					</div>
					<div class="col-md-1 col-lg-1 col-xs-1">
						<label for="pwd">Fecha Fin: </label>
					</div>
					<div class="col-md-2 col-lg-2 col-xs-2">
						<input type="date"  class="form-control" name="fechafin" id="fechafin">
					</div>
                    <button type="button" class="btn btn-success" id="btn_reporteVenta" data-url="<?php echo getUrl("Recibo", "Recibo", "buscarReporte", "", "ajax"); ?>">Buscar</button></a>
				</div>
							
			</form>
													
		</div>
	</div>
	
</section>

<section class="hero-section">
	<div class="container">
		<div class="row">
			<div id="div_contenidoReporte_JALF" class="col-md-12"></div>
		</div>
	</div>
</section>