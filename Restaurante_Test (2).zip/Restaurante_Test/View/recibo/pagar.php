<section class="hero-section">
		
		<div class="container" >
			<div class="section-title">
				<h2>Crear Nuevo Recibo de Caja</h2><small><a href="index.php?modulo=Recibo&controlador=Recibo&funcion=index">Ver lista de Recibos de Caja</a></small>
			</div>
			
				<?php foreach($cabecera as $cab){}?>													
				<form name="frm_pedido" method="post" action="<?php echo getUrl("Recibo", "Recibo", "postInsertar"); ?>">
					 <div class="row">
                         <div class="form-group">
							<div class="col-md-1 col-lg-1 col-xs-1">
								<label>No:</label>
							</div>
							<div class="col-md-1 col-lg-1 col-xs-2">
								<input type="num_doc" readonly class="form-control" name="num_doc" value="<?php echo $num_cons; ?>">
							</div>
							<div class="col-md-1 col-lg-1 col-xs-1">
								<label for="pwd">Fecha: </label>
							</div>
							<div class="col-md-2 col-lg-2 col-xs-2">
								<input type="text" readonly class="form-control" name="fecha" value="<?php echo $cab['ped_fecha']; ?>">
							</div>
							<div class="col-md-1 col-lg-1 col-xs-3 text-center">
								<label>No Pedido:</label>
							</div>
							<div class="col-md-1 col-lg-1 col-xs-2">
								<input type="number" class="form-control"  id="no_pedido" name="no_pedido" value="<?php echo $cab['ped_id']; ?>">
							</div>	
							<div class="col-md-1 col-lg-1 col-xs-1">
								<label>Cliente:</label>
							</div>
							<div class="col-md-4 col-lg-4 col-xs-6">
								<select class="form-control" required name="cliente">
									<option value="">Seleccione</option>
									<?php
									foreach($clientes as $cli){                                      
										echo'<option value="'.$cli['cli_id'].'">'.$cli['nombre_cli'].'</option>';
									}
									?>
								</select>
							</div>
						</div>						
					</div>
					
					<br>					
					<table class="table table-bordered" id="table_pedido">
						<thead>
							<tr><th colspan="5" style="text-align:center; background-color:#F0EAE9; ">Detalle del Pedido</th></tr>
							<tr ><th>Plato</th>
							<th width="10%">Precio</th>
							<th width="10%">Cantidad</th>							
							<th width="10%">Subtotal</th>							
							<th width="5%"><button type="button" class="btn btn-primary" id="btn_pedido">+</button></th></tr>
						</thead>
						<tbody id="tbody_pedido">
							<tr id="tr_pedido" style="display:none">
								<td>
									<select name="plato[]" class="form-control ">
										<option>Seleccione</option>
										<?php
											foreach($platos as $plato)
											{
												echo"<option value='".$plato['pla_id']."'>".$plato['pla_descripcion']."</option>";
											}
										?>
									</select>
								</td>
								<td><input type="number" name="precio[]" class="form-control"></td>
								<td><input type="number" name="cantidad[]" class="form-control"></td>							
								<td><input type="number" name="subtotal[]" class="form-control"></td>							
								<td><button type="button" class="btn btn-danger eliminar" id="btn">-</button></td>
							</tr>
                            <?php 
                            $subtotal=0;
                            $total=0;
                            foreach($detalle as $deta){
                                $subtotal=$deta['ped_det_precio'] * $deta['ped_det_cant'];
                                $total+=$subtotal;
                                echo'<tr>
                                    <td>
                                        <select name="plato[]" class="form-control ">'; 
                                        $seleccion="";                                                                                    
                                            foreach($platos as $plato)
                                            {
                                                if($plato['pla_id']==$deta['pla_id']){ $seleccion="selected";}
                                                echo"<option value='".$plato['pla_id']."' $seleccion>".$plato['pla_descripcion']."</option>";
                                                $seleccion="";
                                            }
                                          
                                        echo'</select>
                                    </td>
                                    <td ><input type="number" name="precio[]" required class="form-control text-right" value="'.$deta['ped_det_precio'].'"></td>
                                    <td><input type="number" name="cantidad[]" required class="form-control text-right" value="'.$deta['ped_det_cant'].'"></td>                                   
                                    <td><input type="text" name="subtotal[]" required class="form-control text-right" value="'.number_format($subtotal).'"></td>                                   
                                    <td><button type="button" class="btn btn-danger eliminar" id="btn">-</button></td>
                                </tr>';

                            }
                            
                            echo'<tr>
                                <td colspan="3" class="text-center"><b>Total</b></td><td><input type="text" class="form-control text-right" readonly  value="'.number_format($total).'"></td><td></td>
                            </tr>';
                            ?>
                        </tbody>
                        
					</table>
					
					

					<div class="form-group">
						<div class="col-md-12 col-lg-12 col-xs-12">
							<label>Observaciones:</label>
							<textarea class="form-control" name="observaciones"></textarea>
						</div>
					</div>
					
					
					<div class="form-group">
						<div class="col-md-12 col-lg-12 col-xs-12 text-center">
							<input type="submit" class="btn btn-primary" value="Registrar">
						</div>
					</div>
				</form>
													
			
		</div>
	
</section>