<section class="hero-section">
		
		<div class="container" >
			<div class="section-title">
				<h2>Crear Nuevo Recibo de Caja</h2><small><a href="index.php?modulo=Recibo&controlador=Recibo&funcion=index">Ver lista de Recibos de Caja</a></small>
			</div>
			
																	
				<form name="frm_pedido" method="post" action="<?php echo getUrl("Recibo", "Recibo", "postInsertar"); ?>">
					 <div class="row">
                         <div class="form-group">
							<div class="col-md-1 col-lg-1 col-xs-1">
								<label>No:</label>
							</div>
							<div class="col-md-1 col-lg-1 col-xs-2">
								<input type="num_doc" readonly class="form-control" name="num_doc" value="<?php echo $num_doc; ?>">
							</div>
							<div class="col-md-1 col-lg-1 col-xs-1">
								<label for="pwd">Fecha: </label>
							</div>
							<div class="col-md-2 col-lg-2 col-xs-2">
								<input type="date" required class="form-control" name="fecha">
							</div>
							<div class="col-md-1 col-lg-1 col-xs-3 text-center">
								<label>No Pedido:</label>
							</div>
							<div class="col-md-1 col-lg-1 col-xs-2">
								<input type="number" class="form-control"  id="no_pedido" name="no_pedido">
							</div>	
							<div class="col-md-1 col-lg-1 col-xs-1">
								<label>Cliente:</label>
							</div>
							<div class="col-md-4 col-lg-4 col-xs-6">
								<select class="form-control" required name="cliente">
									<option value="">Seleccione</option>
									<?php
									foreach($clientes as $cli){
										echo'<option value="'.$cli['cli_id'].'">'.$cli['nombre_cli'].'</option>';
									}
									?>
								</select>
							</div>
						</div>						
					</div>
					
					<br>					
					<table class="table table-bordered" id="table_pedido">
						<thead>
							<tr><th colspan="5" style="text-align:center; background-color:#F0EAE9; ">Detalle del Pedido</th></tr>
							<tr ><th>Plato</th>
							<th width="10%">Precio</th>
							<th width="10%">Cantidad</th>
							<th width="35%">Observaciones</th>
							<th width="5%"><button type="button" class="btn btn-primary" id="btn_pedido">+</button></th></tr>
						</thead>
						<tbody id="tbody_pedido">
							<tr id="tr_pedido" style="display:none">
								<td>
									<select name="plato[]" class="form-control ">
										<option>Seleccione</option>
										<?php
											foreach($platos as $plato)
											{
												echo"<option value='".$plato['pla_id']."'>".$plato['pla_descripcion']."</option>";
											}
										?>
									</select>
								</td>
								<td><input type="number" name="precio[]" class="form-control"></td>
								<td><input type="number" name="cantidad[]" class="form-control"></td>
								<td><input type="text" name="observa[]" class="form-control"></td>
								<td><button type="button" class="btn btn-danger eliminar" id="btn">-</button></td>
							</tr>

							<tr>
								<td>
									<select name="plato[]" class="form-control ">
										<option>Seleccione</option>
										<?php
											foreach($platos as $plato)
											{
												echo"<option value='".$plato['pla_id']."'>".$plato['pla_descripcion']."</option>";
											}
										?>
									</select>
								</td>
								<td><input type="number" name="precio[]" required class="form-control"></td>
								<td><input type="number" name="cantidad[]" required class="form-control"></td>
								<td><input type="text" name="observa[]" required class="form-control"></td>
								<td><button type="button" class="btn btn-danger eliminar" id="btn">-</button></td>
							</tr>
						</tbody>
					</table>
					
					

					<div class="form-group">
						<div class="col-md-12 col-lg-12 col-xs-12">
							<label>Observaciones:</label>
							<textarea class="form-control" name="observaciones"></textarea>
						</div>
					</div>
					
					
					<div class="form-group">
						<div class="col-md-12 col-lg-12 col-xs-12 text-center">
							<input type="submit" class="btn btn-primary" value="Registrar">
						</div>
					</div>
				</form>
													
			
		</div>
	
</section>