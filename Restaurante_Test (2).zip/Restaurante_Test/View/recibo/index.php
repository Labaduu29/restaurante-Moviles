<section class="hero-section">
		
		<div class="container" >
			
			<div class="row">
				<div class="col-md-9 col-xs-3 section-title">
					<h2>Recibos de Caja</h2>						
				</div>
				<br>
				<div class="col-md-3 col-xs-3"><a href="<?php echo getUrl("Recibo","Recibo","getInsertar");?>">
						<button type="submit" class="btn btn-success">Crear un Nuevo Recibo de Caja </button></a>
				</div>
			</div>
			<div class="row">
	
				<table class="table tables" id="table_recibo">
					<thead>
						
						<tr>							
							<th >No Recibo</th>
							<th >Fecha</th>					
							<th >Cliente</th>					
							<th >Estado</th>
							<th >Ver</th>
							<th >Imprimir</th>
						</tr>
					</thead>
					<tbody id="tbody_recibo">
						<?php
						if(isset($Recibos)){
							
							foreach($Recibos as $recibo){
								echo'<tr>';
								echo'<td>'.$recibo['rc_num'].'</td>
								<td>'.$recibo['rc_fecha'].'</td>
								<td>'.$recibo['cli_nombre'].' '.$recibo['cli_apellidos'].'</td>
								<td>'.$recibo['rc_estado'].'</td>								
								<td><a href="index.php?modulo=Recibo&controlador=Recibo&funcion=ver&num_doc='.$recibo['rc_num'].'">
									<button type="button" class="btn btn-success " id="btn">Ver más</button>
								</a></td>
								<td><a href="imprimirrecibo.php?num_doc='.$recibo['rc_num'].'" target="_blank">
									<button type="button" class="btn btn-success"><i class="fa fa-print fa-lg"></i></button></a>
								</td>
							</tr>';
							}
						}
						else{
							echo"<tr><td></td><td>No hay Registros</td></tr>";
						}
						?>
					</tbody>
				</table>															
			</div>
		</div>
	
</section>