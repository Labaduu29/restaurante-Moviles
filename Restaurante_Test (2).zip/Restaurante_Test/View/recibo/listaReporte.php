<table class="table">
	<thead>
		
		<tr>							
			<th>No Recibo</th>
			<th>Fecha</th>					
			<th>Cliente</th>					
			<th>Mesero</th>			
			<th>Total</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
		<?php
			if($registros->num_rows > 0){
				
				foreach($registros as $recibo){
					echo'<tr>';
					echo'<td>'.$recibo['rc_num'].'</td>
					<td>'.$recibo['rc_fecha'].'</td>
					<td>'.$recibo['nombrecliente'].'</td>
					<td>'.$recibo['nombremesero'].'</td>
					<td>'.$recibo['total_doc'].'</td>
											
					<td><a href="index.php?modulo=Recibo&controlador=Recibo&funcion=ver&num_doc='.$recibo['rc_num'].'">
						<button type="button" class="btn btn-success " id="btn">Ver más</button>
					</a></td>
					<td><button type="button" class="btn btn-success"><i class="fa fa-print fa-lg"></i></button></td>
				</tr>';
				}
			}
			else{
				echo"<tr><td></td><td>No hay Registros</td></tr>";
			}
		?>
	</tbody>
</table>
	