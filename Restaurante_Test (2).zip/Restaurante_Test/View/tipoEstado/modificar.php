<?php $tes = mysqli_fetch_object($te);?>
<section class="hero-section">
<div class="container">
	<div class="section-title">
		<h2>Modificar Tipo Estado</h2>
	</div>
	<div class="row">											
		<form method="post" action="<?php echo getUrl("TipoEstado","TipoEstado","postModificar"); ?>">
		<div class="form-group">
			<div class="col-md-1 col-lg-1 col-xs-1">
				<label > N°</label>
			</div>	
			<div class="col-md-1 col-lg-1 col-xs-1">
				<input readonly type="text" name="tes_id" class="form-control" value="<?php echo $tes->tes_id; ?>">
			</div>	
				
			<div class="col-md-1 col-lg-1 col-xs-1">
					<label> Descripci&oacute;n </label>
				</div>
				<div class="col-md-2 col-lg-2 col-xs-2">
					<input type="text" class="form-control" name="tes_descripcion"  value= "<?php echo UTF8_encode($tes->tes_descripcion); ?>">
				</div>
			</div>	
			<div class="col-md-1 col-lg-1 col-xs-1">
				<label> Estado </label>
			</div>
				<div class="col-md-2 col-lg-2 col-xs-2">
					<input type="text" class="form-control" name="tes_estado" value= "<?php echo UTF8_encode($tes->tes_estado); ?>" >
				</div>
			</div>
		</div>
			<br>
			<div class="form">
			<div class="col-md-7 col-lg-7 col-xs-7" style="text-align:center">
					<button class="btn btn-primary" type="submit">Guardar</button>
					<a class='btn btn-default' href="<?php echo getUrl("TipoEstado","TipoEstado","index"); ?>">Cancelar</a> 
				</div>
			</div>
		</form><br><br><br>											
		</div>
	</div>
</section>