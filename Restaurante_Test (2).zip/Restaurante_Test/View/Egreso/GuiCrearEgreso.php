<html lang="en">	
    <body class="smoothscroll enable-animation">
        <div id="wrapper">			
            <section class="page-header page-header-xs text-white h2">
                <div class="container">

                    <!--<h2 class="ocultarMovil titulo-travis">Comprobante de Egreso</h2>-->
                    <h2 class=" travis2 titulo-travis1 titulo-travis">Comprobante de Egreso</h2>                  
                    
                    <!--<span class="fs-18 fw-300">In search for a perfect home</span>-->                
                </div>
            </section>

            <section>
                <div class="container">
                    <div class="box-static box-transparent box-bordered p-30">                      
                        <form name="frm_CrearEgreso" id="frm_CrearEgreso" method="post"  autocomplete="off" action="<?php echo getUrl("Egreso", "Egreso", "RegistrarEgreso"); ?>">	


                            <div class="row">
                                
                                                <div class="col-md-2 col-lg-3 col-xs-12">
                                                    No. *
                                                    <input type="text" required name="no_doc" id="no_doc" readonly class="form-control" value="<?= $numDoc; ?>">
                                                </div>
                                                <div class="col-md-3  col-lg-3 col-xs-12">
                                                    Fecha *<input type="date" name="fecha" required  class="form-control" value="<? echo date('Y-m-d'); ?>">
                                                </div>
                                                <div class="col-md-4 col-lg-3 col-xs-12">
                                                    A favor de *<select name="aFavorDe" class="form-control select2" required>
                                                        <option value="">Seleccione...</option>
                                                        <?php foreach ($terceros as $tercero): ?>
                                                            <option value="<?= $tercero["identificacion"]; ?>" ><?= $tercero["nombre_completo"]; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row">

                                                <div class=" col-lg-3 col-md-3 col-xs-12">
                                                    Concepto *<select name="concepto" class="form-control select2" required>
                                                        <option value="">Seleccione...</option>
                                                        <?php foreach ($conceptos as $concepto): ?>
                                                            <option value="<?= $concepto["con_id"]; ?>" ><?= $concepto["con_descripcion"]; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class=" col-lg-3 col-md-3 col-xs-12">
                                                    No Documento 	<input type="text" required name="no_transaccion"  class="form-control " >
                                                </div>
                                                <div class=" col-lg-3 col-md-3 col-xs-12">
                                                    Forma de Pago *<select name="fp" class="form-control select2" required>
                                                        <option value="">Seleccione...</option>
                                                        <?php foreach ($formasPago as $fp): ?>
                                                            <option value="<?= $fp["fp_id"]; ?>" ><?= $fp["fp_descripcion"]; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class=" col-lg-3 col-md-3  col-xs-12">
                                                    Valor Pagado * <input type="text" name="valorPagado" required class="form-control format">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-10  ocultarMovil">
                                                    Detalle * <textarea name="detalle" required class="form-control" col="70"></textarea>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-lg-3 ocultarMovil "><a href="<?php echo getUrl("Egreso", "Egreso", "getCrearEgreso"); ?>" class="btn btn-primary" title="Nuevo Comprobante de Egreso">
                                                        <i class="fa fa-file "></i>NUEVO
                                                    </a>
                                                </div>

                                                <div class="col-lg-3 col-xs-6">
                                                    <button type="submit" class="btn btn-primary" title="Guardar Comprobante de Egreso">
                                                        <i class="fa fa-check"></i>GUARDAR</button>
                                                </div>
                                            </div>
                                        </div>        
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </section>
        </div>
    </body>
</html>


<script src="../view/Egreso/js/egreso.js"></script>

