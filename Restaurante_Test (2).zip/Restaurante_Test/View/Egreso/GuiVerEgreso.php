<form name="frm_VerEgreso" id="frm_VerEgreso" method="post"  autocomplete="off" action="#">
	<?php foreach($egresos as $egreso){} ?>
	<div class="row">
		<div class="col-12">
			<div class="page-header">
				<div class="pb-3 align-items-center row">
					<div class="col-md-4 col-xs-12">
						<h2 class="pageheader-title">Comprobante de Egreso - Ver</h2>
					</div>
					
					<div class="col-md-6 col-xs-12">
						<a href="<?php echo getUrl("Egreso", "Egreso", "VistaCrearEgreso");?>" class="btn btn-primary" title="Nuevo Comprobante de Egreso">
										<i class="fa fa-file fa-lg"></i>
						</a>

						<button type="submit" class="btn btn-primary" title="Imprimir Comprobante de Egreso">
							<i class="fa fa-print fa-lg"></i>
						</button>
						
						<button type="button" id="anularEgreso" class="btn btn-primary" title="Anular Comprobante de Egreso">
							<i class="fa fa-trash fa-lg"></i>
						</button>

					</div>
					
					<div class="col-md-2 col-xs-12">
						<?php if($egreso["estado"]=="A"): ?>
							<h4><span class="badge badge-primary">ACTIVO</span></h4>
						<?php elseif($egreso["estado"]=="I"): ?>
							<h4><span class="badge badge-danger">ANULADO</span></h4>
						<?php endif; ?>
					</div>
				</div>
                
                <div class="page-breadcrumb">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="javascript:void(0)" class="breadcrumb-link">Archivos</a></li>
							<li class="breadcrumb-item active" aria-current="page">Comprobante de Egreso</li>
						</ol>
					</nav>
				</div>
				
			</div>
		</div>
	</div>

					
	 <div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
		    <div class="card">
				<div class="card-body">
        		<div class="row">
        			<div class="col-12">
        				<div class="row">
        				    <div class="col-md-2 col-xs-6">
        					    No. *
        								<input type="text" required name="no_doc" id="no_doc" readonly class="form-control" value="<?= $egreso['no_egreso'];?>">
        					</div>
        					<div class="col-md-2 col-xs-6">
        					    Fecha *<input type="text" name="fecha" required readonly class="form-control" value="<? echo substr($egreso['fecha_documento'],0,10); ?>">
        					</div>
        					<div class="col-md-4 col-xs-6">
        					   A favor de *<select name="aFavorDe" class="form-control select2" disabled>
											<option value="" ><?=$egreso["nombre_completo"];?></option>
								</select>
        					</div>
        				</div>
        				
        				<div class="row">
        				    
        					<div class="col-md-3 col-xs-6">
        					   Concepto *<select name="concepto" class="form-control select2" disabled>
											<option value="" ><?=$egreso["concepto"];?></option>
								</select>
        					</div>
        					<div class="col-md-3 col-xs-6">
        					   No Documento 	<input type="text" readonly name="no_transaccion"  class="form-control " value="<?= $egreso['no_documento'];?>" >
        					</div>
        					<div class="col-md-3 col-xs-6">
        					   Forma de Pago *<select name="fp" class="form-control select2" readonly>
									<option value="" ><?=$egreso["formasP"];?></option>
								</select>
        					</div>
        				    <div class="col-md-2  col-xs-6">
        					    Valor Pagado * <input type="text" name="valorPagado" readonly class="form-control format" value="<?= $egreso['valor_egreso'];?>">
        					</div>
        				</div>
        				
        				<div class="row">
        				    <div class="col-md-11  col-xs-6">
        					    Detalle * <textarea name="detalle" readonly class="form-control" col="70"><?= $egreso['detalle'];?></textarea>
        					</div>
        				</div>
        				
        			</div>
        
        		</div>
        	</div>
        </div>
	</div>
</div>
		
</form>

<!-- MODAL BUSCAR Tarifas-->
<div class="modal fade" id="modalTarifas">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">

			<div class="text-center modal-header">
				<h3 class="w-100 modal-title">Tarifas</h3>
				<button type="button" class="close" data-dismiss="modal" title="Cerrar">
					<i class="fa fa-window-close fa-2x text-danger"></i>
				</button>
			</div>

			<div class="modal-body">
                <div class="container">
                    <div class="row"><div class="col-md-6">	<h3>Seleccione la Tarifa deseada</h3></div></div>
                	<div class="nuevaBusqueda" id="containerTablaModalTarifas" style="display: none;">
                	    <div class="table-responsive">
                		<table id="tablaModalTarifas" class="table table-bordered table-hover" width="100%;">
                
                			<thead class="table text-white bg-primary thead-primary">
                				<tr>
                					<th>No</th>
                					<th>Programa</th>
                					<th>Periodo</th>
                					<th>No Sesi贸n</th>
                					<th>Valor</th>
                					<th>Estado</th>
                				</tr>
                			</thead>
                
                			<tbody></tbody>
                
                		</table>
                		</div>
                	</div>
                </div>
			</div>

		</div>
	</div>
</div>


<script src="../../views/Egreso/js/egreso.js?v="<?=rand();?>></script>

	