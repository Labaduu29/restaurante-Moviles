$(document).ready(function(){   
    $(document).on("click", "#btnNuevaBusqueda", function () {
		$(".nuevaBusqueda").hide();
		$("#menu-ir-a-egresos").hide();
		$("#frm_ModalBuscarEgresos")[0].reset();
	});
	
	
	/** Buscar Facturas  **/	

	$(function anularEgreso() {
		$(document).on("click", "#anularEgreso", function () {
			let estado = $("span:contains(ACTIVO)").length == 1 ? "ACTIVO" : "ANULADO";
			let formData = new FormData($("#frm_VerEgreso")[0]);
			
			if (estado == "ACTIVO") {
				alertify.confirm(//html
					`<h4>Está segur(a) que desea eliminar el Comprobante de Egreso</h4>`
				).set({
					closable: false,
					labels: { ok: "Sí", cancel: "No" },
					onok: () => {
    					alertify.prompt( //html
    						`<h4>Ingrese la razón por la cuál anula</h4>`, "",
    						(evt, value) => {
    							if (value) {
    								formData.append("razon_anula", value);
    								$.ajax({
    									url: "ajax.php?modulo=Egreso&controlador=Egreso&funcion=anularEgreso",
            							method: "post",
            							data: formData,
            							dataType: "json",
            							processData: false,
            							contentType: false
    								}).done((res) => {
    									alertify.notify(res.mensaje, res.tipoRespuesta, 4, () => {
    										if (res.tipoRespuesta == "success") {
    											window.location.reload();
    										}
    									});
    								});
    							}
    						}
    					).set({
    						closable: false,
    						labels: {
    							ok: "Aceptar",
    							cancel: "Cancelar"
    						}
    					}).setHeader("");
    				},
					
					
					
					
					
					
					
					
					
					/*onok: () => {
						$.ajax({
							url: "ajax.php?modulo=Egreso&controlador=Egreso&funcion=anularEgreso",
							type: "post",
							data: "no_doc="+no_doc,
						}).done((res) => {
							alertify.notify(res.mensaje, res.tipoRespuesta, 4, () => {
								if (res.tipoRespuesta == "success") {
									window.location.href=res.url;
								}
							});
						});
					},*/
				}).setHeader("");
			} else if (estado == "ANULADO") {
				alertify.notify("El registro se encuentra anulado", "warning", 4);
			}
		});
	});	
	
	 $(".format").each(function () {
    		new Cleave(this, {
    			numeral: true,
    			numeralThousandsGroupStyle: "thousand"
    		});
    });
        
	
});