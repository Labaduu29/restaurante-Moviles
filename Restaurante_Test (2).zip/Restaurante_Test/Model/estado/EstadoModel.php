<?php
include_once '../model/MasterModel.php';
	class EstadoModel extends MasterModel{
		
	}
?>