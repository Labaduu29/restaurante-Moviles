<?php
@session_start();

class EgresoController {
    
    public function getCrearEgreso(){	   	  
        //$consNum= 1; //$this->consultar("ultimo_creado", "consecutivo_documentos", " td_sigla='CE'");
        //foreach( $consNum as  $cons){ 
        $numDoc= 1; //$cons['ultimo_creado'];}
        //$conceptos=$this->consultar("con_id, con_descripcion", "concepto", "con_estado='Activo' order by con_descripcion");
        //$formasPago=$this->consultar("fp_id, fp_descripcion", "forma_pago", "fp_estado='Activo' order by fp_descripcion");        
        //$terceros=$this->consultar("identificacion, razon_social as nombre_completo", "terceros", " estado='A' order by nombre_completo");
        include_once'../view/Egreso/GuiCrearEgreso.php';
    }
            
}
?>